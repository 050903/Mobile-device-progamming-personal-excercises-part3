//settings.gradle.kts
pluginManagement {
    repositories {
        google() // KHÔNG CÓ content {} block ở đây
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "JetpackComposeUIApp"
include(":app")
 