package com.example.jetpackcomposeuiapp

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.jetpackcomposeuiapp.ui.theme.JetpackComposeUIAppTheme

data class UIComponent(val name: String, val description: String, val route: String)

val uiComponents = listOf(
    UIComponent("Text", "Displays text", "text_detail"),
    UIComponent("Image", "Displays an image", "image_detail"),
    UIComponent("TextField", "Input field for text", "textfield_detail"),
    UIComponent("PasswordField", "Input field for passwords", "passwordfield_detail"),
    UIComponent("Column", "Arranges elements vertically", "column_detail"),
    UIComponent("Row", "Arranges elements horizontally", "row_detail")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComponentsListScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("UI Components List") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Display section header
            item {
                Text(
                    text = "Display",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Divider(color = Color.LightGray)
            }
            items(uiComponents.filter { it.name == "Text" || it.name == "Image" }) { component ->
                ComponentListItem(component = component) {
                    navController.navigate(component.route)
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Input",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Divider(color = Color.LightGray)
            }
            items(uiComponents.filter { it.name == "TextField" || it.name == "PasswordField" }) { component ->
                ComponentListItem(component = component) {
                    navController.navigate(component.route)
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Layout",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Divider(color = Color.LightGray)
            }
            items(uiComponents.filter { it.name == "Column" || it.name == "Row" }) { component ->
                ComponentListItem(component = component) {
                    navController.navigate(component.route)
                }
            }
        }
    }
}

@Composable
fun ComponentListItem(component: UIComponent, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = component.name,
                style = MaterialTheme.typography.titleMedium,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = component.description,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewComponentsListScreen() {
    JetpackComposeUIAppTheme {
        ComponentsListScreen(rememberNavController())
    }
}