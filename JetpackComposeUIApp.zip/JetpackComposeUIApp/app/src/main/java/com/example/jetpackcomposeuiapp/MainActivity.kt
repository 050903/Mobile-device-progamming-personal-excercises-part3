//MainActivity.kt
package com.example.jetpackcomposeuiapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.jetpackcomposeuiapp.ui.theme.JetpackComposeUIAppTheme
// Bạn có hai dòng import MaterialTheme và Surface. Chỉ cần một dòng là đủ.
// import androidx.compose.material3.MaterialTheme // Dòng này bị lặp lại, có thể xóa
// import androidx.compose.material3.Surface     // Dòng này bị lặp lại, có thể xóa

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { // <-- Đây là lần gọi setContent đúng
            JetpackComposeUIAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

// XÓA ĐOẠN CODE NÀY!
// setContent {
//     MaterialTheme {
//         Surface {
//             // Nội dung UI của bạn
//         }
//     }
// }

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "welcome_screen") {
        composable("welcome_screen") {
            WelcomeScreen(onReadyClick = {
                navController.navigate("components_list_screen")
            })
        }
        composable("components_list_screen") {
            ComponentsListScreen(navController = navController)
        }
        composable(
            "components_detail_screen/{componentName}",
            arguments = listOf(navArgument("componentName") { type = NavType.StringType })
        ) { backStackEntry ->
            val componentName = backStackEntry.arguments?.getString("componentName")
            // Ánh xạ tên route sang tên hiển thị trên TopAppBar
            val displayName = when (componentName) {
                "text_detail" -> "Text Detail"
                "image_detail" -> "Image Detail"
                "textfield_detail" -> "TextField Detail"
                "passwordfield_detail" -> "PasswordField Detail"
                "column_detail" -> "Column Detail"
                "row_detail" -> "Row Detail"
                else -> "Chi tiết thành phần"
            }
            ComponentsDetailScreen(componentName = displayName, navController = navController)
        }
        // Thêm các composable cụ thể cho từng chi tiết nếu bạn muốn các màn hình riêng biệt
        // Hiện tại, chúng ta sử dụng một màn hình chi tiết chung
        composable("text_detail") {
            ComponentsDetailScreen(componentName = "Text Detail", navController = navController)
        }
        composable("image_detail") {
            ComponentsDetailScreen(componentName = "Image Detail", navController = navController)
        }
        composable("textfield_detail") {
            ComponentsDetailScreen(componentName = "TextField Detail", navController = navController)
        }
        composable("passwordfield_detail") {
            ComponentsDetailScreen(componentName = "PasswordField Detail", navController = navController)
        }
        composable("column_detail") {
            ComponentsDetailScreen(componentName = "Column Detail", navController = navController)
        }
        composable("row_detail") {
            ComponentsDetailScreen(componentName = "Row Detail", navController = navController)
        }
    }
}