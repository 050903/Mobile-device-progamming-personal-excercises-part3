package com.example.jetpackcomposeuiapp
import androidx.compose.ui.text.AnnotatedString

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.jetpackcomposeuiapp.ui.theme.JetpackComposeUIAppTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComponentsDetailScreen(componentName: String?, navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(componentName ?: "Component Detail") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            when (componentName) {
                "Text Detail" -> TextDetailContent()
                "Image Detail" -> ImageDetailContent()
                "TextField Detail" -> TextFieldDetailContent()
                "PasswordField Detail" -> PasswordFieldDetailContent()
                "Column Detail" -> ColumnDetailContent()
                "Row Detail" -> RowDetailContent()
                else -> Text("Không tìm thấy chi tiết cho $componentName")
            }
        }
    }
}

@Composable
fun TextDetailContent() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(modifier = Modifier.height(32.dp))
        Text(
            text = buildAnnotatedString {
                append("The quick ")
                withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)) {
                    append("Brown")
                }
                append("\nfox jumps ")
                withStyle(style = SpanStyle(fontStyle = FontStyle.Italic, fontSize = 24.sp)) {
                    append("over")
                }
                append("\nthe ")
                withStyle(style = SpanStyle(textDecoration = TextDecoration.Underline, color = Color.Gray)) {
                    append("lazy")
                }
                append(" dog.")
            },
            fontSize = 32.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 40.sp // Tăng khoảng cách dòng để dễ đọc hơn
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("Đây là ví dụ về Composable Text với các kiểu định dạng khác nhau: in đậm, in nghiêng, gạch chân và màu sắc.",
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

private fun AnnotatedString.Builder.withStyle(
    style: SpanStyle,
    function: () -> Unit
) {
}

@Composable
fun ImageDetailContent() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(modifier = Modifier.height(32.dp))
        Image(
            painter = painterResource(id = R.drawable.jetpack_compose_logo1), // Thêm ảnh này vào drawable
            contentDescription = "Jetpack Logo",
            modifier = Modifier
                .size(200.dp)
                .background(Color.LightGray.copy(alpha = 0.3f)),
            contentScale = ContentScale.Fit
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("Composable Image hiển thị một hình ảnh từ tài nguyên drawable.",
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextFieldDetailContent() {
    var text by remember { mutableStateOf("") }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(modifier = Modifier.height(32.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Nhập văn bản vào đây") },
            modifier = Modifier.fillMaxWidth(0.8f)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("Nội dung đã nhập: $text",
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("Composable TextField cho phép người dùng nhập văn bản.",
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasswordFieldDetailContent() {
    var password by remember { mutableStateOf("") }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(modifier = Modifier.height(32.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Nhập mật khẩu") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(0.8f)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("Mật khẩu đã nhập (không hiển thị): ${"*".repeat(password.length)}",
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("Composable TextField với `visualTransformation = PasswordVisualTransformation()` để che dấu mật khẩu.",
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun ColumnDetailContent() {
    Column(
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .height(250.dp)
            .background(Color.Cyan.copy(alpha = 0.2f))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {
        Text("Item 1", modifier = Modifier.background(Color.Blue.copy(alpha = 0.5f)).padding(8.dp), color = Color.White)
        Text("Item 2", modifier = Modifier.background(Color.Green.copy(alpha = 0.5f)).padding(8.dp), color = Color.White)
        Text("Item 3", modifier = Modifier.background(Color.Red.copy(alpha = 0.5f)).padding(8.dp), color = Color.White)
    }
    Spacer(modifier = Modifier.height(16.dp))
    Text("Composable Column sắp xếp các phần tử con theo chiều dọc.",
        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        style = MaterialTheme.typography.bodyMedium
    )
}

@Composable
fun RowDetailContent() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp)
            .background(Color.Magenta.copy(alpha = 0.2f))
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Left", modifier = Modifier.background(Color.Yellow.copy(alpha = 0.5f)).padding(8.dp))
        Text("Center", modifier = Modifier.background(Color.Gray.copy(alpha = 0.5f)).padding(8.dp), color = Color.White)
        Text("Right", modifier = Modifier.background(Color.DarkGray.copy(alpha = 0.5f)).padding(8.dp), color = Color.White)
    }
    Spacer(modifier = Modifier.height(16.dp))
    Text("Composable Row sắp xếp các phần tử con theo chiều ngang.",
        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        style = MaterialTheme.typography.bodyMedium
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewComponentsDetailScreen() {
    JetpackComposeUIAppTheme {
        ComponentsDetailScreen("Text Detail", rememberNavController())
    }
}