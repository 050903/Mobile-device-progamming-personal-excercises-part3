package com.example.gdnduxui.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    // Tùy chỉnh màu sáng
)

private val DarkColors = darkColorScheme(
    // Tùy chỉnh màu tối
)

@Composable
fun GdnduxuiTheme(
    content: @Composable () -> Unit
) {
    val colors = LightColors // Hoặc thêm logic để chọn sáng/tối

    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
