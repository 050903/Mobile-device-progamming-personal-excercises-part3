package com.example.gdnduxui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.gdnduxui.ui.theme.GdnduxuiTheme // Giữ nguyên theme của bạn

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GdnduxuiTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DynamicUIComponentsScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DynamicUIComponentsScreen() {
    // ---- Quản lý trạng thái cho các thành phần tương tác ----
    var buttonText by remember { mutableStateOf("Nhấn vào đây!") }
    var textFieldValue by remember { mutableStateOf("Đây là trường văn bản") }
    var isChecked by remember { mutableStateOf(false) }
    var selectedOption by remember { mutableStateOf("Option 1") } // For Radio Buttons
    var switchOn by remember { mutableStateOf(true) }
    var sliderProgress by remember { mutableFloatStateOf(0.7f) }

    // State for the custom toggle switch
    var customToggleState by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .background(Color(0xFFF0F0F0)),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // ---- 1. BUTTON (Nút bấm) ----
        Button(
            onClick = { buttonText = "Đã nhấn!" },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(buttonText)
        }

        // ---- 2. TEXT FIELD (Trường nhập liệu văn bản) ----
        TextField(
            value = textFieldValue,
            onValueChange = { textFieldValue = it },
            label = { Text("Nhập liệu ở đây") },
            modifier = Modifier.fillMaxWidth()
        )

        // ---- 3. CHECKBOX & RADIO BUTTONS (Hộp kiểm & Nút radio) ----
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Checkbox(
                    checked = isChecked,
                    onCheckedChange = { isChecked = it }
                )
                Text("Kiểm tra")
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = (selectedOption == "Option 1"),
                        onClick = { selectedOption = "Option 1" }
                    )
                    Text("Lựa chọn 1")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = (selectedOption == "Option 2"),
                        onClick = { selectedOption = "Option 2" }
                    )
                    Text("Lựa chọn 2")
                }
            }
        }

        // ---- 4. SWITCH (Công tắc bật/tắt chuẩn Material Design) ----
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Trạng thái công tắc:")
            Switch(
                checked = switchOn,
                onCheckedChange = { switchOn = it }
            )
        }

        // ---- 5. SLIDER (Thanh trượt) ----
        Slider(
            value = sliderProgress,
            onValueChange = { sliderProgress = it },
            modifier = Modifier.fillMaxWidth()
        )
        Text("Giá trị: ${(sliderProgress * 100).toInt()}%")

        // Sửa lỗi ở đây: chỉ cần modifier là đủ
        HorizontalDivider(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Color.Gray.copy(alpha = 0.5f))
        )

        // ---- 6. CUSTOM TOGGLE SWITCH (Nút On/Off kiểu chữ nhật chia đôi) ----
        Text("Custom Toggle Switch:", style = MaterialTheme.typography.titleSmall)
        CustomToggleSwitch(
            state = customToggleState,
            onToggle = { customToggleState = it }
        )

        // Sửa lỗi ở đây: chỉ cần modifier là đủ
        HorizontalDivider(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Color.Gray.copy(alpha = 0.5f))
        )

        // ---- 7. LAYOUT EXAMPLES (Ví dụ bố cục) ----
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Ví dụ Bố cục:", style = MaterialTheme.typography.titleMedium)

            // A. COLUMN Layout
            Text("Column:", style = MaterialTheme.typography.titleSmall)
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .height(150.dp)
                    .background(Color(0xFFE0F7FA), RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.SpaceAround,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                repeat(3) { index ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth(0.8f)
                            .height(35.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = when(index) {
                                0 -> Color(0xFF81C784)
                                1 -> Color(0xFF66BB6A)
                                else -> Color(0xFF4CAF50)
                            }
                        )
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Item $index", color = Color.White)
                        }
                    }
                }
            }

            // B. ROW Layout
            Text("Row:", style = MaterialTheme.typography.titleSmall)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
                    .background(Color(0xFFE3F2FD), RoundedCornerShape(8.dp))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(3) { index ->
                    Card(
                        modifier = Modifier
                            .width(80.dp)
                            .height(50.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = when(index) {
                                0 -> Color(0xFF90CAF9)
                                1 -> Color(0xFF64B5F6)
                                else -> Color(0xFF42A5F5)
                            }
                        )
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Box $index", color = Color.White)
                        }
                    }
                }
            }

            // C. BOX Layout (Cập nhật để xếp chồng rõ ràng hơn)
            Text("Box (xếp chồng):", style = MaterialTheme.typography.titleSmall)
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .background(Color(0xFFFFEBEE), RoundedCornerShape(8.dp))
                    .padding(10.dp),
                contentAlignment = Alignment.BottomEnd // Căn dưới cùng bên phải để các lớp lộ ra
            ) {
                // Các lớp xếp chồng từ dưới lên trên
                // Lớp dưới cùng, lớn nhất
                Card(
                    modifier = Modifier
                        .size(120.dp)
                        .align(Alignment.Center) // Căn giữa lớp nền
                        .offset(x = 0.dp, y = 0.dp), // Vẫn giữ ở giữa
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFCCBC)) // Màu nhạt nhất
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Layer 1", color = Color.Black.copy(alpha = 0.7f))
                    }
                }

                // Lớp giữa, nhỏ hơn một chút, lệch sang trái/trên
                Card(
                    modifier = Modifier
                        .size(100.dp)
                        .align(Alignment.Center)
                        .offset(x = (-15).dp, y = (-15).dp), // Dịch chuyển lên trên và sang trái
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFAB91)) // Màu giữa
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Layer 2", color = Color.White)
                    }
                }

                // Lớp trên cùng, nhỏ nhất, lệch nhiều nhất về trái/trên
                Card(
                    modifier = Modifier
                        .size(80.dp)
                        .align(Alignment.Center)
                        .offset(x = (-30).dp, y = (-30).dp), // Dịch chuyển nhiều hơn
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFF7043)) // Màu đậm nhất
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Layer 3", color = Color.White)
                    }
                }
            }
        }
    }
}

// ---- CUSTOM TOGGLE SWITCH COMPOSABLE ----
@Composable
fun CustomToggleSwitch(
    state: Boolean,
    onToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    // Kích thước của công tắc
    val width = 120.dp
    val height = 40.dp
    val handleSize = 60.dp // Kích thước của cục trượt

    // Màu nền và màu của cục trượt
    val backgroundColor by animateColorAsState(
        targetValue = if (state) Color(0xFF66BB6A) else Color(0xFFE0E0E0), // Green for ON, Light Gray for OFF
        animationSpec = tween(durationMillis = 300)
    )
    val handleColor by animateColorAsState(
        targetValue = if (state) Color.White else Color.White,
        animationSpec = tween(durationMillis = 300)
    )
    val textColorOn by animateColorAsState(
        targetValue = if (state) Color.White else Color.Black.copy(alpha = 0.7f),
        animationSpec = tween(durationMillis = 300)
    )
    val textColorOff by animateColorAsState(
        targetValue = if (state) Color.Black.copy(alpha = 0.7f) else Color.White,
        animationSpec = tween(durationMillis = 300)
    )

    // Vị trí cục trượt
    val handleOffset by animateDpAsState(
        targetValue = if (state) width - handleSize else 0.dp,
        animationSpec = tween(durationMillis = 300)
    )

    Box(
        modifier = modifier
            .width(width)
            .height(height)
            .background(backgroundColor, RoundedCornerShape(height / 2)) // Bo tròn góc
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null // Bỏ hiệu ứng ripple mặc định
            ) {
                onToggle(!state)
            },
        contentAlignment = Alignment.Center
    ) {
        // Lớp nền chứa chữ "OFF" và "ON"
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("OFF", color = textColorOff, style = MaterialTheme.typography.bodyMedium)
            Text("ON", color = textColorOn, style = MaterialTheme.typography.bodyMedium)
        }

        // Cục trượt hình chữ nhật
        Box(
            modifier = Modifier
                .offset(x = handleOffset) // Dịch chuyển cục trượt
                .size(handleSize, height) // Kích thước cục trượt
                .background(handleColor, RoundedCornerShape(height / 2)) // Bo tròn góc
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            // Có thể thêm icon hoặc text vào cục trượt nếu muốn
            // Text(if (state) "ON" else "OFF", color = Color.Black)
        }
    }
}


// Preview để xem trước UI trong Android Studio
@Preview(showBackground = true, widthDp = 360, heightDp = 900)
@Composable
fun DynamicUIComponentsScreenPreview() {
    GdnduxuiTheme {
        DynamicUIComponentsScreen()
    }
}

@Preview(showBackground = true)
@Composable
fun CustomToggleSwitchPreview() {
    GdnduxuiTheme {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            var state1 by remember { mutableStateOf(false) }
            CustomToggleSwitch(state = state1, onToggle = { state1 = it })

            var state2 by remember { mutableStateOf(true) }
            CustomToggleSwitch(state = state2, onToggle = { state2 = it })
        }
    }
}