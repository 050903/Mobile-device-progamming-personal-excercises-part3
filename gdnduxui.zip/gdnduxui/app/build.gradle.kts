// app/build.gradle.kts
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android") // Áp dụng plugin ở đây
}

android {
    namespace = "com.example.gdnduxui"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.gdnduxui"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    buildFeatures {
        compose = true // Bật Jetpack Compose
    }

    // Cấu hình Compose Options
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8" // Hoặc "1.5.10" - Quan trọng là phải tương thích với Kotlin 1.9.22
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Cân nhắc dùng version.ref từ libs.versions.toml để nhất quán
    implementation(libs.androidx.core.ktx) // Sử dụng libs.androidx.core.ktx từ libs.versions.toml
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation ("com.google.android.material:material:1.9.0")
    implementation ("androidx.compose.material3:material3:1.1.0")
    val composeBomVersion = "2024.05.00" // Cập nhật phiên bản BOM
    implementation(platform("androidx.compose:compose-bom:$composeBomVersion"))
    androidTestImplementation(platform("androidx.compose:compose-bom:$composeBomVersion"))

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")

    // Thêm các dependency còn thiếu từ libs.versions.toml nếu bạn muốn dùng chúng trong app
    // Ví dụ:
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    // Nếu bạn dùng các thư viện này:
    // implementation(libs.androidx.appcompat)
    // implementation(libs.material)
    // implementation(libs.androidx.activity) // Đã có activity-compose ở trên, cái này có thể trùng
    // implementation(libs.androidx.constraintlayout)
}