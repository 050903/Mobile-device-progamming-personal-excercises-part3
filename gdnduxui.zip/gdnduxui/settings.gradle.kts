// settings.gradle.kts (ĐÃ SỬA CHỮA CHÍNH XÁC)
pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal() // Quan trọng: Kho lưu trữ cho các plugin Gradle
    }
    plugins {
        // KHÔNG CÓ "apply false" ở đây. Đây là nơi bạn khai báo plugin để Gradle tìm thấy.
        id("com.android.application") version "8.9.2" // Phiên bản này phải khớp với libs.versions.toml agp
        id("org.jetbrains.kotlin.android") version "1.9.22" // Phiên bản này phải khớp với libs.versions.toml kotlin
        id("org.jetbrains.compose") version "1.5.8" // <--- Đảm bảo dòng này CÓ và ĐÚNG version
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "gdnduxui"
include(":app")